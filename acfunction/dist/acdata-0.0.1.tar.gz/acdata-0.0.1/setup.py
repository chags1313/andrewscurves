import setuptools

setuptools.setup(
	name = 'acdata',
	version = '0.0.1',
	author = 'Cole Hagen',
	description = 'A python module to format a dataframe for plotting Andrews Curves',
	packages=['acdata'])